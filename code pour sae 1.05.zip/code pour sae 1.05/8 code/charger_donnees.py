def charger_donnees(tcpdump_file):
    """Charger les données du fichier tcpdump et extraire les informations nécessaires."""
    with open(tcpdump_file, 'r', encoding="utf-8") as file:
        data = file.readlines()  # Lire toutes les lignes du fichier tcpdump
    return data
