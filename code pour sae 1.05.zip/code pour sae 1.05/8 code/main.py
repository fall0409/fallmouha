import pandas as pd
from charger_donnees import charger_donnees
from analyser_donnees import analyser_donnees
from sauvegarder_csv import sauvegarder_csv
from detecter_menaces import detecter_menaces
from generer_rapport_markdown import generer_rapport_markdown
from generer_graphiques import generer_graphiques
from generer_page_web import generer_page_web

# Fichiers d'entrée/sortie
tcpdump_file = "wireshark.txt"
csv_output_file = "network_traffic.csv"
suspicious_report_file = "suspicious_activity_report.md"
graph_output_file = "network_traffic_graphs.png"

# Exécution du script
data = charger_donnees(tcpdump_file)
df = analyser_donnees(data)
sauvegarder_csv(df, csv_output_file)
suspicious_activity, connections_per_source, short_packet_counts = detecter_menaces(df)
generer_rapport_markdown(suspicious_activity, connections_per_source, short_packet_counts, df, suspicious_report_file)
generer_graphiques(connections_per_source, short_packet_counts, graph_output_file)
generer_page_web(suspicious_activity, connections_per_source, short_packet_counts, df, graph_output_file)

print(f"Fichier Markdown sauvegardé dans {suspicious_report_file}.")
print(f"Fichier CSV sauvegardé dans {csv_output_file}.")
print(f"Graphiques sauvegardés dans {graph_output_file}.")
