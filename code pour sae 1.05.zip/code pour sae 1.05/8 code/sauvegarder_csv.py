def sauvegarder_csv(df, csv_output_file):
    """Sauvegarder les données dans un fichier CSV."""
    df.to_csv(csv_output_file, index=False)  # Enregistrer le DataFrame sous forme de fichier CSV
