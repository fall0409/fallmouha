
    # Rapport de Détection de Menaces Réseau

    ## Résumé des Résultats
    - Nombre total de paquets analysés : **6259**
    - Nombre d'adresses IP sources uniques : **2074**
    - Nombre d'adresses IP destinations uniques : **75**

    ## Menaces Potentielles Détectées
    <br>**DDoS possible :** IP(s) source avec trop de connexions<br>- mauves.univ-st-etienne.fr.https : 1612 connexions détectées<br>- par10s38-in-f3.1e100.net.https : 827 connexions détectées<br>- BP-Linux8.34862 : 255 connexions détectées<br>- par21s17-in-f1.1e100.net.https : 180 connexions détectées<br>- BP-Linux8.40678 : 153 connexions détectées<br>- BP-Linux8.40682 : 143 connexions détectées<br>- BP-Linux8.40684 : 114 connexions détectées<br>- BP-Linux8.40680 : 111 connexions détectées<br>**Flood possible :** IP(s) envoyant beaucoup de paquets courts<br>- BP-Linux8.34862 : 214 paquets courts détectés<br>- par10s38-in-f3.1e100.net.https : 152 paquets courts détectés<br>- BP-Linux8.40678 : 141 paquets courts détectés<br>- BP-Linux8.40682 : 136 paquets courts détectés<br>- BP-Linux8.40684 : 107 paquets courts détectés<br>- BP-Linux8.40680 : 103 paquets courts détectés<br>- BP-Linux8.40679 : 76 paquets courts détectés<br>- BP-Linux8.40683 : 71 paquets courts détectés<br>- par21s17-in-f1.1e100.net.https : 54 paquets courts détectés<br>**Statistiques des flags TCP :**<br>- P. : 827 occurrences<br>- . : 3362 occurrences<br>- S : 2025 occurrences<br>- S. : 25 occurrences<br>- F. : 20 occurrences

    ## Statistiques Complètes
    ### Connexions par IP Source (Top 10)
    |   count |
|--------:|
|    1612 |
|     827 |
|     255 |
|     180 |
|     153 |
|     143 |
|     114 |
|     111 |
|      85 |
|      77 |

    ### Paquets Courts par IP Source (Top 10)
    |   count |
|--------:|
|     214 |
|     152 |
|     141 |
|     136 |
|     107 |
|     103 |
|      76 |
|      71 |
|      54 |
|      50 |
    