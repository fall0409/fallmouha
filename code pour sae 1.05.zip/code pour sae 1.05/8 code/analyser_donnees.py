import re
import pandas as pd

def analyser_donnees(data):
    """Analyser les données pour extraire les informations pertinentes avec une expression régulière."""
    pattern = r"(\d{2}:\d{2}:\d{2}\.\d+)\s+IP\s+(\S+)\s>\s(\S+):\sFlags\s+\[(\S+)\],.*length\s+(\d+)"
    records = []

    for line in data:
        match = re.search(pattern, line)
        if match:
            time, src_ip, dest_ip, flags, length = match.groups()  # Extraire les groupes correspondant aux données
            records.append({
                "Heure": time,  # Heure du paquet
                "IP Source": src_ip,  # Adresse IP source
                "IP Destination": dest_ip,  # Adresse IP destination
                "Flags": flags,  # Flags TCP
                "Longueur": int(length)  # Longueur du paquet
            })

    # Convertir les données extraites en DataFrame pandas
    return pd.DataFrame(records)
