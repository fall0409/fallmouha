def generer_rapport_markdown(suspicious_activity, connections_per_source, short_packet_counts, df, suspicious_report_file):
    """Générer un rapport Markdown avec les informations de menaces détectées."""
    markdown_content = f"""
    # Rapport de Détection de Menaces Réseau

    ## Résumé des Résultats
    - Nombre total de paquets analysés : **{len(df)}**
    - Nombre d'adresses IP sources uniques : **{df["IP Source"].nunique()}**
    - Nombre d'adresses IP destinations uniques : **{df["IP Destination"].nunique()}**

    ## Menaces Potentielles Détectées
    {''.join([f"<br>{item}" for item in suspicious_activity])}

    ## Statistiques Complètes
    ### Connexions par IP Source (Top 10)
    {connections_per_source.head(10).to_markdown(index=False)}

    ### Paquets Courts par IP Source (Top 10)
    {short_packet_counts.head(10).to_markdown(index=False)}
    """

    with open(suspicious_report_file, "w", encoding="utf-8") as file:
        file.write(markdown_content)
