from collections import Counter

def detecter_menaces(df):
    """Détecter les menaces potentielles (DDoS, Flood, anomalies TCP) dans les données."""
    suspicious_activity = []  # Liste pour stocker les descriptions des activités suspectes

    # Détection DDoS : Identifier les IPs avec un grand nombre de connexions
    connections_per_source = df["IP Source"].value_counts()  # Compter les connexions par IP source
    threshold_ddos = 100  # Seuil pour identifier un DDoS
    suspicious_ips_ddos = connections_per_source[connections_per_source > threshold_ddos].index.tolist()

    if suspicious_ips_ddos:
        suspicious_activity.append("**DDoS possible :** IP(s) source avec trop de connexions")
        for ip in suspicious_ips_ddos:
            suspicious_activity.append(f"- {ip} : {connections_per_source[ip]} connexions détectées")

    # Détection de flood : IPs envoyant beaucoup de paquets courts
    short_packets = df[df["Longueur"] < 50]  # Filtrer les paquets de courte longueur
    short_packet_counts = short_packets["IP Source"].value_counts()
    threshold_flood = 50  # Seuil pour identifier un flood
    suspicious_ips_flood = short_packet_counts[short_packet_counts > threshold_flood].index.tolist()

    if suspicious_ips_flood:
        suspicious_activity.append("**Flood possible :** IP(s) envoyant beaucoup de paquets courts")
        for ip in suspicious_ips_flood:
            suspicious_activity.append(f"- {ip} : {short_packet_counts[ip]} paquets courts détectés")

    # Anomalies TCP : Analyse des flags TCP pour détecter une activité inhabituelle
    flag_counts = Counter(df["Flags"])  # Compter les occurrences de chaque type de flag TCP
    suspicious_activity.append("**Statistiques des flags TCP :**")
    for flag, count in flag_counts.items():
        suspicious_activity.append(f"- {flag} : {count} occurrences")

    return suspicious_activity, connections_per_source, short_packet_counts
