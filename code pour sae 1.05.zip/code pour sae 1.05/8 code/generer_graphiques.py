import matplotlib.pyplot as plt

def generer_graphiques(connections_per_source, short_packet_counts, graph_output_file):
    """Générer des graphiques pour illustrer les résultats de l'analyse."""
    plt.figure(figsize=(12, 6))

    # Graphique 1: Connexions par IP Source (Top 10)
    plt.subplot(1, 2, 1)
    connections_per_source.head(10).plot(kind="pie", autopct='%1.1f%%', title="Top 10 des Connexions par IP Source", ylabel="")
    plt.ylabel("")

    # Graphique 2: Paquets Courts par IP Source (Top 10)
    plt.subplot(1, 2, 2)
    short_packet_counts.head(10).plot(kind="pie", autopct='%1.1f%%', title="Top 10 des Paquets Courts par IP Source", ylabel="")
    plt.ylabel("")

    plt.tight_layout()
    plt.savefig(graph_output_file)  # Enregistrer les graphiques dans un fichier image
