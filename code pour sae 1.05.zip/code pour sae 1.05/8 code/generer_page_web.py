def generer_page_web(suspicious_activity, connections_per_source, short_packet_counts, df, graph_output_file):
    """Générer une page web HTML avec un rapport et des graphiques pour un thème de cybersécurité sombre."""
    html_content = f"""
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Rapport de Surveillance Réseau</title>
        <style>
            body {{
                font-family: 'Courier New', Courier, monospace;
                background-color: #0d1117;
                color: #c9d1d9;
                margin: 0;
                padding: 0;
            }}
            h1 {{
                background-color: #21262d;
                color: #58a6ff;
                padding: 15px;
                text-align: center;
                border-bottom: 2px solid #58a6ff;
            }}
            h2 {{
                color: #58a6ff;
                border-bottom: 1px solid #21262d;
                padding-bottom: 5px;
            }}
            p, ul {{
                font-size: 16px;
                line-height: 1.8;
            }}
            ul {{
                list-style-type: none;
                padding-left: 0;
            }}
            li {{
                margin: 10px 0;
            }}
            .container {{
                max-width: 1200px;
                margin: 20px auto;
                padding: 20px;
                background-color: #161b22;
                border-radius: 8px;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            }}
            img {{
                max-width: 100%;
                height: auto;
                margin-top: 20px;
                border: 2px solid #58a6ff;
            }}
            pre {{
                background-color: #21262d;
                color: #58a6ff;
                padding: 10px;
                border-radius: 5px;
                overflow-x: auto;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
            }}
            th, td {{
                border: 1px solid #58a6ff;
                padding: 10px;
                text-align: left;
            }}
            th {{
                background-color: #21262d;
                color: #c9d1d9;
            }}
            td {{
                background-color: #161b22;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Rapport de Surveillance Réseau</h1>
            <p><strong>Résumé des analyses :</strong></p>
            <ul>
                <li>Total des paquets inspectés : {len(df)}</li>
                <li>Nombre d'adresses IP sources uniques : {df["IP Source"].nunique()}</li>
                <li>Nombre d'adresses IP cibles uniques : {df["IP Destination"].nunique()}</li>
            </ul>
            <h2>Activités Suspectes Détectées</h2>
            <p>{''.join([f"<br>{item}" for item in suspicious_activity])}</p>

            <h2>Visualisation des Données :</h2>
            <img src="{graph_output_file}" alt="Graphique de surveillance réseau">

            <h2>Tableaux des Connexions et Paquets Anormalement Courts par IP Source</h2>
            <h3>Top 10 des Connexions par IP Source</h3>
            <pre>{connections_per_source.head(10).to_markdown(index=False)}</pre>

            <h3>Top 10 des Paquets Anormalement Courts par IP Source</h3>
            <pre>{short_packet_counts.head(10).to_markdown(index=False)}</pre>
        </div>
    </body>
    </html>
    """
    html_report_file = "network_traffic_report.html"
    with open(html_report_file, "w", encoding="utf-8") as file:
        file.write(html_content)
    print(f"Page Web générée : {html_report_file}.")
